import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';


/*
  Generated class for the Data provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class Data {

  constructor(public storage: Storage, public http: Http){

  }

  getData() {
    return this.storage.get('invites');
  }

  saveInvite(data){
    //let newData = JSON.stringify(data);
    this.storage.set('invites', data);
  }

  uploadData(data){
    var url = 'http://youthconference.blwcampusministry.com/index.php/api/input';
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url,JSON.stringify(data),options)
    .map(res => {return res.json()})

  }

}
