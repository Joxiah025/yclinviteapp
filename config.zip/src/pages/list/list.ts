import { Component } from '@angular/core';
import { NavController, LoadingController, ToastController} from 'ionic-angular';
import { Data } from '../../providers/data';
import { CallNumber } from '@ionic-native/call-number';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  public invites: any;
  public length: any;


  constructor(public navCtrl: NavController,  public toastCtrl: ToastController, public dataService: Data, public loadingCtrl: LoadingController, private callNumber: CallNumber) {
  this.dataService.getData().then((invites) => {
    if(invites){
        this.invites = invites.slice().reverse();
        this.length = this.invites.length;
      }
      console.log(this.invites);
    });

  }

  ionViewWillEnter(){
    this.dataService.getData().then((invites) => {
      if(invites){
        this.invites = invites.slice().reverse();;
      }
    });
      console.log(this.invites);
  }


  upload(item){
    let loader = this.loadingCtrl.create({
      content: "Please wait...",
      spinner: "ios"
    });
    loader.present();
    this.dataService.uploadData(item).subscribe(
      data => {
        if(data.message == 200){
          let index = this.invites.indexOf(item, 0);
          if (index > -1) {
            this.invites[index].uploaded = 1;
            this.dataService.saveInvite(this.invites);
            console.log(this.invites);
          }
          loader.dismiss();
          let toast = this.toastCtrl.create({
            message: 'Successfully uploaded!',
            duration: 3000,
            position: 'middle'
          });
          toast.present();
        }else{
        loader.dismiss();
        let toast = this.toastCtrl.create({
          message: 'Could not upload successfully, try again!',
          duration: 5000,
          position: 'bottom'
        });
        toast.present();
        }
      },
      error => {
        loader.dismiss();
        let toast = this.toastCtrl.create({
          message: 'Check your internet connection!',
          duration: 5000,
          position: 'bottom'
        });
        toast.present();
      }
    );


  }

  delete(item){

  for(var i = 0; i < this.invites.length; i++) {
    if(this.invites[i].id == item){
        this.invites.splice(i, 1);
      }
    }
    this.dataService.saveInvite(this.invites);
    this.length = this.invites.length;
    console.log(this.invites);
    console.log(item);
  }

  call(numb){
    this.callNumber.callNumber(numb, true)
    .then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'));
  }

}
