import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { InvitePage } from '../invite/invite';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  invitePeople(){
    this.navCtrl.push(InvitePage);
  }

}
