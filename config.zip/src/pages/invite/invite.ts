import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoadingController, ToastController } from 'ionic-angular';
import { Data } from '../../providers/data';

import { ListPage } from '../list/list';


@Component({
  selector: 'page-invite',
  templateUrl: 'invite.html'
})
export class InvitePage {

  public items = [];
  iForm: FormGroup;
  submitAttempt: boolean = false;

  constructor(private formBuilder: FormBuilder, public navCtrl: NavController,  public loadingCtrl: LoadingController, public toastCtrl: ToastController, public dataService: Data) {
    this.dataService.getData().then((invites) => {
        this.items = invites || [];
      //  console.log(this.items);
    });
    this.iForm = formBuilder.group({
        name: ['', Validators.compose([Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
        phone: ['', Validators.compose([Validators.maxLength(30), Validators.pattern('[0-9 ]*'), Validators.required])],
        email: ['', Validators.compose([Validators.required])],
        location: ['', Validators.compose([Validators.required])],
        time: [new Date()],
        id: [Math.round((new Date()).getTime() / 1000)],
        uploaded: [0]
    });

  }

  ionViewWillEnter(){
    this.dataService.getData().then((invites) => {
      if(invites){
        this.items = invites;
      }
    });
      console.log(this.items);

  }


  saveInput(){


      this.submitAttempt = true;


    let loader = this.loadingCtrl.create({
      content: "Please wait...",
      spinner: "ios"
    });
    loader.present();

    if(!this.iForm.valid){
      loader.dismiss();

    }else{
    this.items.push(this.iForm.value);
        this.dataService.saveInvite(this.items);
        loader.dismiss();
        let toast = this.toastCtrl.create({
          message: 'Successfully saved!',
          duration: 3000,
          position: 'middle'
        });
        toast.present();
        this.iForm.reset();
        this.iForm = this.formBuilder.group({
            name: ['', Validators.compose([Validators.maxLength(30), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
            phone: ['', Validators.compose([Validators.maxLength(30), Validators.pattern('[0-9 ]*'), Validators.required])],
            email: ['', Validators.compose([Validators.required])],
            location: ['', Validators.compose([Validators.required])],
            time: [new Date()],
            id: [Math.round((new Date()).getTime() / 1000)],
            uploaded: [0]
        });
        this.submitAttempt = false;
    }

  }

  presentLoading() {
   let loader = this.loadingCtrl.create({
     content: "Please wait...",
     duration: 3000
   });
   loader.present();
 }


  gotoList(){
    this.navCtrl.push(ListPage);
  }

}
