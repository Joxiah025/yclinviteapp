import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HomePage } from '../home/home';

@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html'
})
export class WelcomePage {
slides = [
 {
   title: "It's Youth Conference Lagos!",
   description: "Happening on the <b>9th of June 2017</b> @ the University of Lagos Sports Complex.",
   image: "assets/img/logo.png",
 },
 {
   title: "Catch Us Live @ #ycl2017",
   description: "<b>ADA</b>, <b>FRANK EDWARDS</b>, <b>TB1</b>, <b>UR FLAMES</b>, <b>EBEN</b> and <b>JAHDIEL</b>",
   image: "assets/img/logo.png",
 }
];

  constructor(public navCtrl: NavController) {

  }

  nextMain(){
    this.navCtrl.push(HomePage);
  }
}
